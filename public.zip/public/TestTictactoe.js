
let currentWatcher;

let currentWatcheruid;

let CurrentTurn;

let uiduserO;
let uiduserX;
const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
console.log("UrlParams: ",urlParams.get("roomid"));

const gameRef = firebase.database().ref(`RoomList/${urlParams.get("roomid")}`);

const Gameuid = `${urlParams.get("roomID")}`;

const userList = firebase.database().ref("UserList");

const boardRef = firebase.database().ref(`xoGame/${urlParams.get("roomid")}`);
const btnJoins =  document.querySelectorAll(".btn-join");
btnJoins.forEach((btnJoins) => btnJoins.addEventListener("click", joinGame));

var playerturn;


// ADD New //
var win = false;

const Elements =  document.querySelectorAll(".table-col");
Elements.forEach((el) => el.addEventListener("click", getID));
function getID(event) {
    console.log("======================== Click! ======================"); // [FIXED] log ออกมาดูว่ากดปุ่มติดมั้ย
    gameRef.get().then((snapshot) => {
        console.log(snapshot.val().Turn)
        console.log(snapshot.val().Winner)
        let turn = snapshot.val().Turn;
        let winner = snapshot.val().Winner;
        let userO = snapshot.val().userO;
        console.log("UserO: ",userO)
        // [FIXED] เราลอง log snapshot มาดู มันจะดึง key มา ซึ่ง key พวกนี้เรารู้อยู่แล้ว ไม่ต้อง loop ก็ได้ครับ ที่ก่อนหน้านี้ที่เรา loop เพราะว่าเราไม่รู้ว่ามันมี key ห้องอะไรด้วย
        // snapshot.forEach((data) => {
            const gameInfo = snapshot.key;
            const Currentuid = firebase.auth().currentUser.uid;
            let playersO;
            let playersX;
            // [FIXED] เราเผลอดุงข้อมูล gameRef ข้างบนอยู่แล้ว เราไม่ต้องไปดึงมาซ้ำนะ
            // gameRef.once("value",(check) => {
                console.log("User Turn:",`User${turn}`)
                let userplayer = `User${turn}`; //`user${turn}`= UserO
                playersO = snapshot.val().UserO; // [FIXED] เปลี่ยนจาก check -> snapshot
                playersX = snapshot.val().UserX; // [FIXED] เปลี่ยนจาก check -> snapshot
                console.log("Check val: ", snapshot.val()) // [FIXED] เปลี่ยนจาก check -> snapshot
                console.log("UserO: ",playersO)
                console.log(gameInfo)
                console.log("CurrentTarget.innerText: ", event.currentTarget.innerText)
                console.log("Winner: ",winner)
                console.log("Current Target :", event.currentTarget.id);
                if(CurrentTurn == turn){
                    if ((event.currentTarget.innerText == "" && winner == "" && (playersO == Currentuid || playersX == Currentuid))){
                        console.log("in condition");
                        gameRef.update({
                            LastClick: event.currentTarget.id,
                        });
                        document.querySelector(`#${event.currentTarget.id}`).innerText = snapshot.val().Turn;
                        // [FIXED] เราเข้าถึงห้องได้แล้ว เราไม่ต้อง .child เข้าไปอีกนะ มันเลยเป็น null ลองดูจาก database เก่าได้ มัน child เข้า null ไป มันเลยผิด
                        // boardRef.child(Gameuid).update({
                        boardRef.update({
                            "row-1-col-1" :  document.querySelector("#row-1-col-1").innerText,
                            "row-1-col-2" :  document.querySelector("#row-1-col-2").innerText,
                            "row-1-col-3" :  document.querySelector("#row-1-col-3").innerText,
                            "row-2-col-1" :  document.querySelector("#row-2-col-1").innerText,
                            "row-2-col-2" :  document.querySelector("#row-2-col-2").innerText,
                            "row-2-col-3" :  document.querySelector("#row-2-col-3").innerText,
                            "row-3-col-1" :  document.querySelector("#row-3-col-1").innerText,
                            "row-3-col-2" :  document.querySelector("#row-3-col-2").innerText,        
                            "row-3-col-3" :  document.querySelector("#row-3-col-3").innerText,
                        })
                        checkResult();
                    }
                }
                // });
            
                
            // }).catch((error) => {
            //     console.error(error);
            // })
            console.log("======================== Clicked END! ======================"); // [FIXED] log ออกมาดูว่ากดปุ่มติดมั้ย
      });
}

gameRef.on("value", (snapshot) =>{
    console.log("snapshot: ",snapshot.val().UserO);
    currentWatcher = firebase.auth().currentUser;
    currentWatcheruid = firebase.auth().currentUser.uid;
    uiduserO = snapshot.val().UserO;
    uiduserX = snapshot.val().UserX;
    if((uiduserO != "" || uiduserO != undefined) && (uiduserX != "" || uiduserX != undefined)){
        console.log("Game Start");
        if(uiduserO == currentWatcheruid){
            CurrentTurn = "O";
        }
        if(uiduserX == currentWatcheruid){
            CurrentTurn = "X";
        }
        boardRef.update({
            "row-1-col-1" :  "",
            "row-1-col-2" :  "",
            "row-1-col-3" :  "",
            "row-2-col-1" :  "",
            "row-2-col-2" :  "",
            "row-2-col-3" :  "",
            "row-3-col-1" :  "",
            "row-3-col-2" :  "",        
            "row-3-col-3" :  "",
        })
        // updateboard();
        gameRef.update({
            // [FIXED] เจอปัญหาละ เนื่องจากมันมีค่าเปลี่ยนแปลงทุกครั้ง เลยทำให้ turn นั้นถูก Set เป็น O ทุกครั้ง มันเลยไม่ยอมเปลี่ยน turn ให้ เราอาจจะต้องสร้างห้อง อาจจะบังคับเลยก็ได้ว่า turn แรกเป็น O จะได้ไม่ต้องมาเซ็ตแบบนี้อีก
            // Turn:"O",
            state:"start",
        })
        CheckPleyType();
        getID
        console.log("Player",playerturn);
        console.log("Current UID:",snapshot.key);
        getGameInfo(snapshot.key);
        console.log("LastClick: ", snapshot.val().LastClick);
        document.getElementById("GameState").innerHTML = `${snapshot.val().Turn}`;
        document.getElementById("GameState").innerHTML = `${snapshot.val().Turn}`;
        document.getElementById("GameState").innerHTML = `${snapshot.val().Turn}`;

        userList.child(uiduserX).once("value", userdata => {
            usernameplayerX = `Player X: ${userdata.val().username}`;
            document.getElementById("PlayerX").innerHTML = usernameplayerX;
         }); 
        userList.child(uiduserO).once("value", userdata => {
           usernameplayerO = `Player O: ${userdata.val().username}`;
           document.getElementById("PlayerO").innerHTML = usernameplayerO;
        });
    }
    if (currentUser){
        boardRef.on("value", (snapshot) => {
            snapshot.forEach((data) => {
                const gameInfo = data.key;
                console.log(data)
                let content;
                boardRef.child(gameInfo).on("value", (turn) =>{
                    // console.log(turn.val())
                    // console.log(turn.val())
                    content = `<p class="display-4 text-center">${turn.val()}</p>`;
                    // console.log(content)
                   
                })
                document.querySelector(`#${gameInfo}`).innerHTML = `${content}`;
                getID();
            });
        })
    }
})

// [FIXED] ไม่ต้องใช้ฟังก์ชันก็ได้ เพราะว่า ยังไงมันเป็น .on มันก้อจะต้องอัปเดตอยู่ดีโดยไม่พึ่งฟังก์ชัน
// function updateboard(){
    
// }


function checkResult() {
    console.log("Check Result Function?");
    gameRef.get().then((snapshot) => {
        // [FIXED] เหมือนบรรทัดที่ 40
        // snapshot.forEach((data) => {
            // const gameInfo = data.key;
            const gameInfo = snapshot.val();
            console.log("checkResult: ",gameInfo);
            let turn = gameInfo["Turn"];
            for(let i = 0;i < 9;i++){
                if((Elements[i].textContent== turn) && (Elements[i+1].textContent== turn) && (Elements[i+2].textContent== turn)){
                    gameRef.update({
                        HaveWinner : true,
                        LastClick: "",
                        Winner: turn,
                    });
                }
                i+=2
            }
            for(let i = 0;i < 3;i++){
                if((Elements[i].textContent== turn) && (Elements[i+3].textContent== turn) && (Elements[i+6].textContent== turn)){
                    gameRef.update({
                        HaveWinner : true,
                        LastClick: "",
                        Winner: turn,
                    });
                }
            }
        
            if((Elements[0].textContent== turn) && (Elements[4].textContent== turn) && (Elements[8].textContent== turn)){
                gameRef.update({
                    HaveWinner : true,
                    LastClick: "",
                    Winner: turn,
                });
            }
            if((Elements[2].textContent== turn) && (Elements[4].textContent== turn) && (Elements[6].textContent== turn)){
                gameRef.update({
                    HaveWinner : true,
                    LastClick: "",
                    Winner: turn,
                });
            }
            if (!win){
                console.log("Why you count?");
                turn = turn == 'O' ? 'X' : 'O';
                console.log(`---------`)
                console.log(`${gameInfo["Winner"]}`)
                gameRef.update({
                    // [FIXED] อย่าพยายามเซ็ตค่าทับนะ มันเลยไม่บันทึก LastClick 
                    LastClick: "",
                    Turn: turn,
                    // [FIXED] มันดึงลงมาจะเป็น string แนะนำให้ parseInt ทุกครั้ง ถ้าเราจะเอามาบวกกับเลข
                    CountTurn: parseInt(gameInfo["countTurn"]) + 1, 
                });
            }
        // });
      }).catch((error) => {
        console.error(error);
    })
    
}





// ADD New //
function CheckPleyType() {
    console.log("CheckPlayerType");
    if (currentWatcher.uid != "") {
        const currentUid = currentWatcher.uid;
        console.log("currentUid : ", currentUid);
        console.log("playerX : ", uiduserX);
        console.log("playerO : ", uiduserO);
        if (currentUid == uiduserX) {
            playerturn = 'X';
        }else if(currentUid == uiduserO){
            playerturn = 'O';
        }
    }
}


function getGameInfo(child) {
    boardRef.child(`${child}`).get().then((snapshot) => {
        console.log("getGame snapshot: ",snapshot.key)
        console.log("getGame snapshot uid: ", snapshot.key)
        console.log("=-=-=-=-=-=-=-=-=-==--=-==--=-=-=-=");
        snapshot.forEach((data) => {
            const gameInfo = data.key;
        if (gameInfo["state"] == "start") {
            console.log("Game Start", snapshot.val().Turn);
            document.getElementById('GameState').innerText = `Turn: ${gameInfo["Turn"]}`;
            if (gameInfo["LastClick"] != "" ) {
                document.querySelector(`#${gameInfo["LastClick"]}`).textContent = gameInfo["Turn"];
            }
            Elements.forEach((el) => el.addEventListener('click', getID));

            console.log(playerturn)
            if (gameInfo["Winner"] != "") {
                console.log('win')
                win = gameInfo["HaveWinner"];
                document.getElementById('GameState').innerText = `Winner : ${gameInfo["Winner"]}`;
                if (playerturn == gameInfo["Winner"] ) {
                    UpdateUserStatus(gameInfo[`user-${gameInfo["Winner"]}-id`],3);
                }
            } else if(gameInfo["CountTurn"] == 9){
                console.log('draw')
                document.getElementById('GameState').innerText = `GAME DRAW`;
                UpdateUserStatus(gameInfo[`user-${playerturn}-id`], 1);
            }
        }

        else{
            Elements.forEach((el) => el.innerHTML =`<p class="display-4 text-center"></p>`);
            Elements.forEach((el) => el.removeEventListener('click', getID));
            win = gameInfo['HaveWinner']
        }
        });
    });   
        // ADD New //
    }



